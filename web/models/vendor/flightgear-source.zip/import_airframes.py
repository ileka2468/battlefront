# SPDX-License-Identifier: GPL-2.0-or-later
"""Import only exterior geometry from FlightGear's GPLv2+ aircraft hangar."""
from concurrent.futures import ThreadPoolExecutor
from collections import defaultdict
from pathlib import Path, PurePosixPath
from io import BytesIO
from urllib.request import urlopen
from urllib.parse import quote, urljoin
import argparse
import html
import json
import re
import zipfile

import numpy as np
from PIL import Image
import trimesh

ROOT = 'https://svn.code.sf.net/p/flightgear/fgaddon/trunk/Aircraft/'
# Use the actual family, even when the available variant/livery differs.
PICKS = {
 'A-10':('a-10','A-10','A10-004-015l3.ac'),
 'A-4':('a-4','a4','a4f.ac'),
 'C-130':('c-130','C130','c130.ac'),
 'E-3':('e-3','E3B','E3B.ac'),
 'F-15':('f-15','F-15','f15c.ac'),
 'F-16':('f-16','f16','f16.ac'),
 'F/A-18':('fa-18','f18','f18.ac'),
 'F-14':('f-14','f-14b','f-14b.ac'),
 'F-22':('f-22','Lockheed-Martin-FA-22A-Raptor','Lockheed-Martin-FA-22A-Raptor.ac'),
 'F-23':('f-23','YF-23','YF23-006-008g11.ac'),
 'MiG-29':('mig-29','Mig-29','mesh_airframe.ac'),
 'Mi-24':('mi-24','Mil-Mi-24','mi24.ac'),
 'Su-25':('su-25','Su-25','Su-25.ac'),
 'Su-27':('su-27','yanes19/SU-27SK','Su-27.ac'),
 'Su-33':('su-33','Sukhoi-Su-33','su33.ac'),
 'UH-60':('uh-60','UH-60','uh60.ac')
}
DROP = re.compile(r'^(UC-|CPT-(?!Canopy)|gear_|interior|cockpit(?!.*glass))|(?:wheel|pilot|tire|launchbar|underbodycamera|landinggear|mainstrut|nosestrut|nosegear|nsgear|lwski|wheelbrake|chocks|ladder|starter|gpu-|refuelhose|glassinside|gearwell|pylon|gunpod|rack-|stores|lightcone|spark)', re.I)
EFFECTS = re.compile(r'flame|afterburner|afetrburner|reheat|exhausttrail|smoke',re.I)
SU27 = 'https://raw.githubusercontent.com/yanes19/SU-27SK/925cb5317f3c66fa323a9e186e24d574e0b0881d/'

def fetch(path,url,required=True):
    if path.is_file():
        return path.read_bytes()
    try:
        with urlopen(url,timeout=25) as f:
            payload = f.read(32_000_001)
        if len(payload)>32_000_000:
            raise ValueError('airframe source is larger than budget')
    except OSError:
        if required: raise
        return None
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_bytes(payload)
    return payload

def ac_scene(data, texture_for):
    if not data.startswith(b'AC3D'):
        raise ValueError('not an AC3D model')
    # The geometry is ASCII; object names/comments sometimes contain Latin-1.
    rows = iter(data.decode('latin1').splitlines())
    materials=[]
    buckets=defaultdict(lambda:[[],[],[]])

    def obj(transform, parent_skip=False):
        val={}
        faces=[]
        pts=np.empty((0,3))
        for row in rows:
            name, _, arg=row.strip().partition(' ')
            if name=='numvert':
                pts=np.asarray([[float(x) for x in next(rows).split()[:3]]
                                for _ in range(int(arg))],dtype=float)
            elif name=='numsurf':
                for _ in range(int(arg)):
                    sf=next(rows).strip().split()
                    mat=next(rows).strip().split()
                    refs=next(rows).strip().split()
                    if not (sf[0]=='SURF' and mat[0]=='mat' and refs[0]=='refs'):
                        raise ValueError(sf)
                    ref=[next(rows).split() for _ in range(int(refs[1]))]
                    if (int(sf[1],16)&0xf) == 0 and len(ref)>=3:
                        faces.append((int(mat[1]),int(sf[1],16),ref))
            elif name=='kids':
                break
            else:
                val[name]=arg
        local=np.eye(4)
        if 'loc' in val: local[:3,3]=[float(x) for x in val['loc'].split()]
        if 'rot' in val: local[:3,:3]=np.asarray([float(x) for x in val['rot'].split()]).reshape(3,3).T
        frame=transform@local
        rawname=val.get('name','').strip('"')
        skip=parent_skip or bool(DROP.search(rawname) or EFFECTS.search(rawname))
        if len(pts) and not skip:
            pts=pts@frame[:3,:3].T+frame[:3,3]
            # AC3D is +X aft, +Y up, +Z right; the viewer uses +Z forward.
            pts=pts[:,[2,1,0]]*[1,1,-1]
            tex=re.search(r'"([^"]+)"',val.get('texture',''))
            texture=tex.group(1) if tex else None
            uvrep=[float(x) for x in val.get('texrep','1 1').split()[:2]]
            uvoff=[float(x) for x in val.get('texoff','0 0').split()[:2]]
            for material,flags,refs in faces:
                # Combine UV seams across a material later, but retain corner UVs.
                key=(texture,material,bool(flags&32))
                p,t,f=buckets[key]
                i=len(p)
                p.extend(pts[int(r[0])] for r in refs)
                t.extend((float(r[1])*uvrep[0]+uvoff[0],float(r[2])*uvrep[1]+uvoff[1]) for r in refs)
                f.extend((i,i+j,i+j+1) for j in range(1,len(refs)-1))
        for _ in range(int(arg)):
            child=next(rows)
            if not child.lstrip().startswith('OBJECT '): raise ValueError(child)
            obj(frame,skip)

    for row in rows:
        if row.startswith('MATERIAL '):
            rgb=re.search(r'\brgb ([^ ]+) ([^ ]+) ([^ ]+)',row)
            trans=re.search(r'\btrans ([^ ]+)',row)
            materials.append(([float(x) for x in rgb.groups()] if rgb else [.76]*3, float(trans.group(1)) if trans else 0))
        elif row.startswith('OBJECT '):
            obj(np.eye(4))
    scene=trimesh.Scene()
    for (asset,mid,double), (v,uv,faces) in buckets.items():
        if len(faces)<2: continue
        col, transparency=materials[mid] if 0<=mid<len(materials) else ([.8]*3,0)
        # Index on positions and UVs; this keeps files small and produces smooth skin.
        data=np.column_stack((v,uv)).round(6)
        packed,index=np.unique(data,axis=0,return_inverse=True)
        color=np.clip([*col,1-transparency],0,1)
        tex=texture_for(asset) if asset else None
        if tex is not None: color[:3]=1
        if transparency>.96 and tex is None: continue
        factor=list((color*255+.5).astype(int))
        mat=trimesh.visual.material.PBRMaterial(baseColorFactor=factor,baseColorTexture=tex,
              metallicFactor=.06,roughnessFactor=.70,doubleSided=double,
              alphaMode='BLEND' if transparency>.08 or (tex and tex.mode=='RGBA') else 'OPAQUE')
        mesh=trimesh.Trimesh(vertices=packed[:,:3],faces=index[np.asarray(faces)],process=False,
                 visual=trimesh.visual.texture.TextureVisuals(uv=packed[:,3:],material=mat))
        scene.add_geometry(mesh)
    if not scene.geometry or not np.isfinite(scene.bounds).all(): raise ValueError('model has no finite exterior')
    return scene

def import_one(row, cache, dst):
    family,(slug,plane,model) = row
    folder=cache/slug
    prefix=SU27 if family=='Su-27' else ROOT+quote(plane)+'/'
    origin=prefix+'Models/'
    src=fetch(folder/model,origin+quote(model))
    for name in ('AUTHORS','AUTHORS.txt','COPYING','LICENSE','README','README.txt'):
        fetch(folder/'notices'/name,prefix+name,False)
    if family=='Su-27':
        fetch(folder/'notices'/'README.md',prefix+'README.md',False)
        if not (folder/'notices'/'LICENSE').exists() and not (folder/'notices'/'COPYING').exists():
            raise ValueError('Su-27 license file not verified')
    known={}
    def tex(name):
        if name in known: return known[name]
        rel=PurePosixPath(name.replace('\\','/'))
        if rel.is_absolute() or '..' in rel.parts: rel=PurePosixPath(rel.name)
        uv=fetch(folder/'textures'/Path(*rel.parts),urljoin(origin,quote(rel.as_posix())),False)
        if not uv:
            known[name]=None
            return None
        pic=Image.open(BytesIO(uv))
        pic.load()
        pic=pic.convert('RGBA' if 'A' in pic.getbands() and pic.getextrema()[-1][0]<255 else 'RGB')
        pic.thumbnail((1024,1024),Image.Resampling.LANCZOS)
        known[name]=pic
        return pic
    scene=ac_scene(src,tex)
    tris=sum(len(g.faces) for g in scene.geometry.values())
    path=dst/(slug+'.glb')
    if scene.extents[0] > scene.extents[2]*1.4:
        # Preserve broad high-wing transports; other aircraft should be +Z-forward.
        print('Broad model',family,scene.extents,flush=True)
    path.write_bytes(scene.export(file_type='glb',include_normals=True))
    print(f'{family}: {tris:,} triangles; {path.stat().st_size:,} bytes; spans {scene.extents.round(2).tolist()}',flush=True)
    return family,{'file':f'/models/vendor/{slug}.glb','source':origin+quote(model),'license':'GPL-2.0-only' if family=='Su-27' else 'GPL-2.0-or-later',
                   'triangles':tris,'revision':'exact source snapshot supplied in the archive','aircraft':plane}

def main():
    a=argparse.ArgumentParser(description=__doc__)
    a.add_argument('cache',type=Path)
    a.add_argument('dst',type=Path)
    cfg=a.parse_args()
    cfg.dst.mkdir(parents=True,exist_ok=True)
    with ThreadPoolExecutor(max_workers=8) as pool:
        jobs=[pool.submit(import_one,r,cfg.cache,cfg.dst) for r in PICKS.items()]
        results={}
        for job in jobs:
            try:
                k,v=job.result(); results[k]=v
            except Exception as err:
                print(f'Skipping unverified asset: {err}',flush=True)
    if not results: raise SystemExit('No downloadable models were usable')
    published=results.copy()
    su35url='https://motionmistry.pk/wp-content/uploads/2026/11/motionmistry-su35-flankere-andertan.zip'
    su35=fetch(cfg.cache/'cc-by-su35.zip',su35url,False)
    if su35:
        with zipfile.ZipFile(BytesIO(su35)) as ext:
            model=ext.read('Su35_FlankerE_andertan.glb')
            notice=ext.read('LICENSE.txt')
        if b'creativecommons.org/licenses/by/4.0' in notice.lower() and model.startswith(b'glTF'):
            (cfg.dst/'su-35.glb').write_bytes(model)
            (cfg.dst/'su-35-license.txt').write_bytes(notice)
            published['Su-35']={'file':'/models/vendor/su-35.glb','source':'https://motionmistry.pk/3d-models/',
                'author':'andertan','license':'CC-BY-4.0','aircraft':'Sukhoi Su-35 Flanker-E','revision':'Motion Mistry redistribution','turn':-90}
    (cfg.dst/'manifest.json').write_text(json.dumps(published,indent=2)+'\n',encoding='utf-8')
    gpl=fetch(cfg.cache/'COPYING', 'https://www.gnu.org/licenses/old-licenses/gpl-2.0.txt',False)
    if not gpl: gpl=fetch(cfg.cache/'COPYING','https://raw.githubusercontent.com/FlightGear/flightgear/next/COPYING')
    with zipfile.ZipFile(cfg.dst/'flightgear-source.zip','w',zipfile.ZIP_DEFLATED) as source:
        source.writestr('COPYING',gpl)
        source.writestr('NOTICE.txt','FlightGear FGAddon exterior aircraft assets, GPL v2 or later. '
            'Adapted to static GLB (geometry selection, axis mapping, texture downsizing); exact corresponding exterior source is included. '
            'See each aircraft notices folder where upstream provides it, and the source URLs in the manifest.\n')
        source.write(Path(__file__), 'import_airframes.py')
        source.writestr('manifest.json',json.dumps(results,indent=2)+'\n')
        for key in results:
            slug=PICKS[key][0]
            for p in (cfg.cache/slug).rglob('*'):
                if p.is_file(): source.write(p,p.relative_to(cfg.cache))
    items=''.join(f'<li>{html.escape(key)} — <a href="{html.escape(row["source"])}">{html.escape(row.get("author","FlightGear community"))} · {html.escape(row["aircraft"])}</a> · {html.escape(row["license"])}</li>' for key,row in sorted(published.items()))
    (cfg.dst/'credits.html').write_text('<!doctype html><html lang="en"><meta charset="utf-8"><title>Battlefront aircraft credits</title>'
        '<main><h1>Aircraft credits</h1><p>FlightGear FGAddon contributors. Original geometry, UVs and textures, '
        'adapted into static GLB files. Variants and liveries may differ from DCS. See each asset’s license. '
        '<a href="https://www.gnu.org/licenses/old-licenses/gpl-2.0.html">GNU GPL v2</a>; '
        '<a href="https://creativecommons.org/licenses/by/4.0/">CC BY 4.0</a>. '
        '<a href="su-35-license.txt">Su-35 credit and original attribution</a>.</p><p>'
        '<a href="flightgear-source.zip">Download the corresponding source, contributor notices and converter</a></p><ul>'
        +items+'</ul><p>Airframes without a sourced model use original Battlefront geometry.</p></main></html>',encoding='utf-8')

if __name__=='__main__':
    main()
